<!DOCTYPE html>
<html>
<title>Cadastro Presenca</title>

<body>
<!-- 
	1 - Execute o xampp
	2 - Copiei e cole o seguinte comando via cmd:
		php -S localhost:9876 -t src/Web
-->
<h3> Meu MB! </h3>
<?php 

include_once '../App.php';
?>

<h4>F12: Console</h4>

</body>
</html>